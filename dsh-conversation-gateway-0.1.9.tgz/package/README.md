Owner: `src/index.ts` / `apply`, `../conversation-control/src/{dsh,codex,gateway,server}.ts`.

此 Cordis 插件安装在正在运行的 DSH 浏览器 profile，通过公开 Host 服务控制明确授权项目内的既有 DSH 对话。Codex 可使用承载目标聊天的共享 app-server WebSocket，或明确配置的本机桌面协调接口；两个传输互斥。插件不会启动第二个 Codex 服务，也不复用旧 `dshcontrol` 的 bridge-owned grant。

默认停止新受理，仅监听 `127.0.0.1:3092`。所有路由必须 Bearer 认证；带 Origin 的请求被拒绝，正文与响应均有大小限制。配置只接受项目根、凭证引用、独立状态目录和执行预算。stateDir 必须在所有授权项目之外；禁止授权包含受保护备份目录的宽泛根。

`GET /v1/health` 报告 accepting/degraded/框架及发现错误；`GET /v1/conversations` 查候选；`GET /v1/conversations/:framework/:id` 读元数据；`POST /v1/operations` 执行固定 ID；`GET /v1/operations/:id` 对账既有操作。HTTP 断开会传递 AbortSignal，尚未进入原生提交的排队命令停止；进入原生提交后可能是 unknown，保持原 ID。

DSH 默认 12 steps / 16 requests / 300000 ms，每 RPC 计数包含 retry，人工输入介入时退出桥接回合预算。暂停前有 pending 输入则拒绝，避免已知 D1；期限到达只在精确回合、队列为空且无人工介入时中断，否则保留队列并阻止后续本 RPC 请求。Codex 默认 300000 ms 的具体回合截止，当前接口不能配置 step/request 上限。原生审批不自动决定。

挂载示例位于 `../conversation-config/dsh-web-conversation.patch.example.yml`，完整操作顺序位于 `../CONVERSATION-CONTROL-HANDOFF.md`。示例保持 disabled、Codex endpoint 为空；不能把独立 app-server 的协议验证当作当前桌面聊天控制成功。

`codexDesktopIpc` 配置包含本机 pipe、只读状态数据库、桌面版本和当前桌面进程 ID。桌面协调协议属于已安装版本的内部接口，版本变化时停止接入；当前进程 ID 校验不参与持久委托身份，维护后仍须显式核对和配置新进程。发现只读授权工作区元数据，操作以真实外部客户端身份进入原生 untrusted 输入和审批流程；冷聊天没有桌面 owner 时返回不可用。每次操作保留原 thread/turn 身份，结果仅包含该回合公开回复。


0.1.3 候选补充：只更新 DSH 回执分类，不包含 World 普通通知积累/批量摘要实现。对精确原生回合中的未决定审批 ID，以及同一 live Agent 的原生 user-questions/request 生命周期，报告 waiting_user；观察器不读取问题正文、不代答、不批准，也不根据问号或旧回合事件猜测等待。审批/问题结束后清除临时等待错误码。回合 completed 后若同一 Agent 仍有 running/stopping 后台 jobs，继续报告 running / BACKGROUND_JOBS_ACTIVE，直到原生后台工作结束才确认完成；failed/unknown 不提升为 completed。预算截止不打断待人工决定的审批/问题，继续保留原生权限、队列和精确回合限制。

0.1.3 保留 0.1.2 的配置接口、端口默认值、stateDir 和 SQLite schema=1；package version 不参与持久 delegation identity。同一已有配置和状态目录可保留身份连续性。这里的兼容性来自源码/构建比较，现场重新挂载、干净重启与真实模型/QQ 验收仍由操作者后续完成。


0.1.4 候选补充：live Agent 已 idle，但最新原生 turn/start 没有对应 turn/end 时，对话状态为 unknown，所有控制能力暂不可用，新 prompt/pause 均拒绝。既有 send/pause 通过原 operationId/requestId/turnId 继续只读对账，返回 NATIVE_TURN_END_MISSING；控制消息或暂停请求的协议受理不能替代原生 turn/end。未得到原回合真实终态之前，不自动重试、重新绑定预算、重复取消或合成 completed/paused；之后只有精确原回合的原生 end 才可恢复终态并清除此标记。这个修复不制造历史事件，也不说明缺 end 的底层原因；当前证据不能证明 SDK hang。0.1.3 的 waiting_user 和后台 jobs 处理、配置、存储身份、SQLite schema=1 与权限边界保留。

取消请求后 Agent 同步 idle 时，只有精确 turn/end 的 reason.kind=aborted 能确认 paused。若该回合已经自然 completed、failed 或原因不明，暂停操作保持 unknown / NATIVE_CANCEL_NOT_CONFIRMED；协议受理不算中断完成。

0.1.5 候选补充：冷恢复时没有 attached Agent，且原生 turn/start 仍缺精确 turn/end，不能仅凭日志推断它仍运行。目标同样 unknown/capabilities[]，原 send/pause ID 返回 NATIVE_TURN_END_MISSING 并允许同 ID 只读对账。观察不会调用 resolveAgent/resume、重新提交 prompt、恢复预算或制造结束事件；晚到的精确原生 end 可恢复相应终态。已 attached 且真实 running 的回合保持既有判断。这个修复仍不证明 SDK hang，配置/账本身份/schema=1/原权限与保护目录边界不变。

## 0.1.6 cold native observation

The native SessionQuery prepared observation can append an in-memory turn/end with reason.kind: interrupted to balance an unfinished durable log. This does not confirm completion or cancellation. The target remains unknown with no command capabilities, and the original send/pause receipt remains unknown with NATIVE_TURN_END_MISSING: the code denotes an unconfirmed real end, including a synthetic viewing closer. No new prompt, resolve, resume or cancellation is issued to repair this state. A later exact real terminal event can reconcile the same operation ID read-only. The actual cause of the missing durable end is not established.

Acceptance uses the installed native compiled SessionQueryEngine and its real SessionObservationReader through the public observeSession method, with a strictly in-memory persistence stub. Native dependencies resolve from the existing CLI installation; no fixture dependency was installed or copied.

## 0.1.7 pinned desktop process verification

The Windows desktop runtime verifier reads the executable Path of the explicitly configured PID through Get-Process. A CIM/WMI query could consume the full 8-second connection deadline before the existing desktop pipe was contacted, leaving the initialized connection rejected. The executable path must still match the pinned installed version and Codex/ChatGPT executable. Missing processes, inaccessible or empty paths, different versions, query timeouts and connection failures remain failures; there is no automatic reconnect or request replay. A failed initialized component requires an explicit operator reload before a new connection attempt.

This transport-only change preserves the same pipe, desktop PID verification, read-only state database, delegated roots, native untrusted-input gate, SQLite schema=1 and durable delegation identity. World remains 0.1.1. Earlier native acceptance proves its recorded source/runtime; mounting 0.1.7 requires separate byte and current shared-backend read evidence.
