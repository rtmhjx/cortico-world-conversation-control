/** Rebuild in memory with an explicit existing toolchain; never installs or changes artifacts. */
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { dirname, isAbsolute, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';

assert.equal(process.argv.length, 3, 'Usage: node tools/verify-source-build.mjs <absolute-existing-Cortico-root>');
assert(isAbsolute(process.argv[2]), 'An absolute existing toolchain path is required.');
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(join(resolve(process.argv[2]), 'package.json'));
const version = require('esbuild/package.json').version;
assert.equal(version, '0.28.2', 'Frozen artifacts were reviewed with esbuild 0.28.2.');
const { build } = require('esbuild');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const matched = [];
for (const name of ['dsh-conversation-gateway', 'cortico-world-conversation-control']) {
  const result = await build({
    absWorkingDir: name === 'cortico-world-conversation-control' ? root : join(root, 'conversation-control'),
    entryPoints: [join(root, name, 'src/index.ts')], outfile: join(root, name, 'lib/index.js'),
    bundle: true, platform: 'node', format: 'esm', target: 'node24', packages: 'external',
    sourcemap: true, logLevel: 'warning', write: false,
  });
  assert.equal(result.outputFiles.length, 2);
  for (const file of result.outputFiles) {
    const expected = readFileSync(file.path);
    assert.equal(sha(file.contents), sha(expected), 'Rebuilt file differs from frozen ' + file.path);
    matched.push(file.path.slice(root.length + 1).replaceAll('\\', '/'));
  }
}
assert.equal(sha(readFileSync(join(root, 'cortico-world-conversation-control/src/ENV_PROMPT.md'))),
  sha(readFileSync(join(root, 'cortico-world-conversation-control/lib/ENV_PROMPT.md'))));
matched.push('cortico-world-conversation-control/lib/ENV_PROMPT.md');
console.log(JSON.stringify({ verified: true, esbuild: version, matched, writes: 0, networkRequests: 0, servicesStarted: 0 }));
