import {readFileSync,readdirSync,lstatSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve,dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const manifest=JSON.parse(readFileSync(join(root,'FILE-MANIFEST.json')));
for(const file of manifest.files){assert(!file.path.includes('..')&&!file.path.startsWith('/'));const p=join(root,file.path);assert(!lstatSync(p).isSymbolicLink());const b=readFileSync(p);assert.equal(createHash('sha256').update(b).digest('hex'),file.sha256,file.path);}
const known=new Set(['FILE-MANIFEST.json',...manifest.files.map(f=>f.path)]);const extras=[];
function walk(dir=''){for(const e of readdirSync(join(root,dir),{withFileTypes:true})){const p=dir?dir+'/'+e.name:e.name;if(e.name==='.git')continue;assert(!e.isSymbolicLink());if(e.isDirectory())walk(p);else if(!known.has(p))extras.push(p);}}
walk();assert.deepEqual(extras,[],'Unexpected files: review before upload');console.log(JSON.stringify({verified:true,files:manifest.files.length,extraFiles:0,networkRequests:0}));
