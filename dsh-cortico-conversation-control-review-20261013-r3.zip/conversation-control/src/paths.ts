import { realpath } from 'node:fs/promises';
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';

export const PROTECTED_ROOT = 'F:/AI/对话备份';
const fold = (p: string) => process.platform === 'win32' ? p.toLowerCase() : p;
export const within = (child: string, root: string): boolean => {
  const r = relative(fold(root), fold(child));
  return r === '' || (!isAbsolute(r) && r !== '..' && !r.startsWith(`..${sep}`));
};
/** Metadata only; preserves missing suffixes and detects existing junctions. */
export async function canonical(path: string): Promise<string> {
  if (!isAbsolute(path)) throw new Error('Absolute workspace required.');
  let p = resolve(path); const tail: string[] = [];
  for (;;) {
    try { return join(await realpath(p), ...tail); }
    catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
      const parent = dirname(p); if (parent === p) throw error;
      tail.unshift(relative(parent, p)); p = parent;
    }
  }
}
/** A delegation may contain the archive; each target still excludes it and its ancestors. */
export async function allowedDelegationRoot(root: string): Promise<boolean> {
  try {
    if (!isAbsolute(root) || within(resolve(root), resolve(PROTECTED_ROOT))) return false;
    const base = await canonical(root), denied = await canonical(PROTECTED_ROOT);
    return fold(base) === fold(resolve(root)) && !within(base, denied);
  } catch { return false; }
}
/** File tools operate inside a whole workspace, so an archive ancestor is not a safe target. */
export async function allowedWorkspace(path: string, roots: string[]): Promise<boolean> {
  try {
    if (!isAbsolute(path) || !roots.length) return false;
    const protectedRoot = resolve(PROTECTED_ROOT);
    if (within(resolve(path), protectedRoot) || within(protectedRoot, resolve(path))) return false;
    const child = await canonical(path), denied = await canonical(protectedRoot);
    if (fold(child) !== fold(resolve(path)) || within(child, denied) || within(denied, child)) return false;
    for (const root of roots) {
      if (!isAbsolute(root)) continue;
      const base = await canonical(root);
      if (within(base, denied)) continue;
      // Changed aliases do not silently become new permissions.
      if (fold(base) !== fold(resolve(root))) continue;
      if (within(child, base)) return true;
    }
    return false;
  } catch { return false; }
}
