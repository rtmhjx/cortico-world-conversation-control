Owner: `src/router.ts` / `ConversationRouter`, `src/gateway.ts` / `ConversationGateway`.

该候选实现把既有 DSH 浏览器与 Codex 会话列为有来源的候选，保存 QQ 操作者的目标选择，按一次性人类确认提交原生动作并跟踪精确回执。模糊描述和相关性由 Cortico Persona 判断；路由器负责身份、选择有效期、幂等、持久状态与收件会话绑定。

`find` 最多五项，保留真实标题或 null、工作区、聊天活动时间、摘要和能力。一个框架无法连接时会返回 `unavailableFrameworks`，不会宣称已经搜索它。`select` 持久化同一 QQ 操作者与会话中的目标，`draft` 展示精确动作与正文，新的“确认执行”消息才能提交。自定义正文必须逐字来自当前人类消息。

World 与 Gateway 各持有独立 SQLite 状态，FULL 同步写入及单进程所有权。配置身份、操作者和连接端点变化会拒绝复用原状态。持久 intent 在原生调用前提交；回执落盘失败使新受理停止并输出一条不含正文的 `persistence.degraded` stderr。重启保留 sending 为 unknown，禁止自动重放。未知目标阻止新的普通命令；原 ID 可继续只读对账。DSH request ID 可预先固定；Codex 在回合 ID 返回前失联无法安全推断该回合。

原生权限不被改宽。DSH 的 check 只允许项目内原生 read，其他工具拒绝；continue/send 的已知文件工具受项目路径守卫，其他行为仍受原生权限管理。Codex check 是只读指令，继承原生权限，没有强制只读沙箱。Codex 的启动 API 没有 CAS；共享客户端可以在最后一次读取与提交之间启动回合。两项原生边界需要正式夹具验收。

运行 `npm --prefix conversation-control run typecheck`、`npm --prefix conversation-control test`、`npm --prefix conversation-control run build`、`npm --prefix conversation-control run verify`。完整装配和证据边界见 `../CONVERSATION-CONTROL-HANDOFF.md`。
