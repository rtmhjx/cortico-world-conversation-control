import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdir, mkdtemp, rmdir, symlink, unlink } from 'node:fs/promises';
import { join } from 'node:path';
import { allowedDelegationRoot, allowedWorkspace } from '../conversation-control/src/paths.ts';

test('whole-drive delegation allows ordinary project workspaces but denies archive and ancestor workspaces', async () => {
  assert.equal(await allowedDelegationRoot('F:/'),true);
  assert.equal(await allowedDelegationRoot('F:/AI'),true);
  assert.equal(await allowedDelegationRoot('F:/AI/对话备份'),false);
  assert.equal(await allowedDelegationRoot('relative-root'),false);
  assert.equal(await allowedWorkspace('F:/CODEX/dsh', ['F:/']), true);
  assert.equal(await allowedWorkspace('F:/AI/ordinary-conversation-fixture', ['F:/']), true);
  for (const path of ['F:/AI/对话备份', 'F:/AI/对话备份/child', 'F:/', 'F:/AI', 'C:/outside-delegation']) {
    assert.equal(await allowedWorkspace(path, ['F:/']), false, path);
  }
});

test('whole-drive delegation refuses workspace junction aliases even to another permitted F-drive project', async t => {
  const scratch=join(process.cwd(),'scratch');await mkdir(scratch,{recursive:true});const base=await mkdtemp(join(scratch,'path-delegation-'));
  const actual=join(base,'actual'),alias=join(base,'alias'),crossDrive=join(base,'cross-drive');await mkdir(actual);await symlink(actual,alias,'junction');await symlink('C:/Windows',crossDrive,'junction');
  t.after(async()=>{await unlink(alias);await unlink(crossDrive);await rmdir(actual);await rmdir(base);});
  assert.equal(await allowedWorkspace(actual,['F:/']),true);
  assert.equal(await allowedWorkspace(alias,['F:/']),false);
  assert.equal(await allowedDelegationRoot(alias),false);
  assert.equal(await allowedWorkspace(crossDrive,['F:/']),false);
  assert.equal(await allowedDelegationRoot(crossDrive),false);
});
