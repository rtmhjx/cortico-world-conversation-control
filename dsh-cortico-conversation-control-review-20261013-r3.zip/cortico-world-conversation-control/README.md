Owner: `src/world.ts` / `ConversationControlWorld`, Cortico World API v5.

0.1.1 按框架、目标会话和 operationId 持久合并 accepted/running 回执，不触发 Core。重要状态和错误提交一次包含此前分类计数的 flush 摘要；后台作业仍在运行时继续暂存。发送前冻结摘要，宿主保存后才确认，重启复用相同 reportId marker；普通记录不进入宿主事件总线。是否向原请求用户报告由模型判断。

`conversationcontrol` 将 QQ 操作者的多轮目标选择与本机会话网关连接。独立 World 页面为 `world:conversationcontrol`，配置段为 `worlds.conversationcontrol`。默认停用；网关地址为 `http://127.0.0.1:3092`，凭证由 `CORTICO_CONVERSATION_CONTROL_TOKEN` 引用解析。`operatorIds` 是获授权 QQ 号码字符串的 JSON 数组，留空时无法启动。

工具为 `conversationcontrol_find`、`conversationcontrol_select`、`conversationcontrol_selected`、`conversationcontrol_draft`、`conversationcontrol_confirm`、`conversationcontrol_status`。0.1.2 的模型工具要求 `originMessageId`：真实 QQ 消息行首 `#` 后的非零安全整数，支持负数。World 在宿主事件库取出真实 `qq.message` 后交给路由器核验来源、数字身份、会话和时效。模型传入的身份、任务原文或 boolean 无法授予操作权。

QQ World 正文格式须保留 `#<message_id>`，与持久 `meta.message_id` 对应。发现使用 `store.grep({source:'qq',keyword:'#'+id,context:0,limit:4097})`，逐个用 `hitCursor` 取回事件；只有精确平台编号和真实类型匹配且在 TTL 内的唯一事件可授权。正文引用、数字前缀碰撞、其他来源不能替代 metadata；跨 QQ 会话重复编号也拒绝。命中超过 4096 时明确拒绝，不从截断结果选一条。历史 QQ 事件总量不构成容量门；同一编号及引用匹配过多需要人工核验。时效用 `Date.parse` 比较，避免时间偏移和分片首尾时间的词法过滤漏项。

旧直接调用方可继续传精确 `originEventCursor`，该参数不再出现在模型 schema 中，且必须与 `originMessageId` 二选一；错误游标不会回退成消息编号或最新事件。内部仍消费真实确认事件游标，同一确认只提交一次。`ORIGIN_NOT_FOUND`、`EVENT_EXPIRED`、`ORIGIN_AMBIGUOUS` 应停止猜测并等待新的真实消息；`ORIGIN_LOOKUP_LIMIT` 需人工处理。此版本保持现有路由存储身份和网关协议，配合 Gateway 0.1.7，不修改 Cortico Core。

`find` 最多返回五个有来源的候选；`select` 的序号从 1 开始。候选与选择按操作者及 QQ 会话隔离并持久化，选择不会控制目标。Persona 根据公开标题、工作区、摘要和聊天活动时间解释相关性；聊天活动时间不表示代码修改时间。

`draft` 记录目标、动作与正文，要求当前人类消息包含动作意图；自定义 `send` 正文必须逐字出现在该消息中。用户看过草稿后，新的真实 QQ 消息才能 `confirm`。`pause`、`continue`、`check`、`send` 的可用性来自目标适配器。操作在原生调用前保存固定 operationId 与确认消息消费记录；未知结果不重发。

路由状态默认位于部署 `data/conversationcontrol/control.sqlite`。World 每次轮询只观察已提交操作。结果 outbox 通过确定 delivery marker 向 Cortico 事件库投递；投递后持久确认失败时，下次轮询查询原 marker，避免重复事件。World 停止时等待在途工具和轮询并释放状态所有权。

`conversationcontrol.result` 保留原始 `recipient`、框架、目标和 operationId。Persona 使用 QQ World 的 `qq_draft/qq_confirm` 回报原收件会话；本 World 不调用 OneBot，不替换 QQ 收件限制。这里的 outbox 确认表示结果已落入 Cortico 事件库，不表示 QQ 消息已发送；QQ 端确认和协议回执属于单独验收。

控制台可查看配置、选择数量、操作状态、待投递与持久化降级。启用指示仅表示路由服务运行；网关能力以实际请求为准。发现和结果使用外部来源，Cortico 内部 Memory 的写入仍由 Persona 决定。

隔离行为验证：

```powershell
node F:/AI/C/cortico/node_modules/tsx/dist/cli.mjs --tsconfig tsconfig.conversation.json --test tests/conversation-world.test.ts
```

这组测试使用真实路由状态库、模拟原生 backend 与 QQ 事件库，不发送 QQ 消息，不调用真实模型。正式装配与原生会话控制、QQ 回报各需独立验收。
