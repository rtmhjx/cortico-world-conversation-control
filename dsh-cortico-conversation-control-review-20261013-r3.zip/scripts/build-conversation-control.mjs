import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, writeFileSync, mkdirSync, copyFileSync, existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire('F:/AI/C/cortico/package.json'), { build } = require('esbuild');
const packages = ['dsh-conversation-gateway', 'cortico-world-conversation-control'];
const paths = [];
function walk(dir) { for (const entry of readdirSync(join(root, dir), { withFileTypes: true })) { if (entry.isSymbolicLink()) throw new Error('Source manifest rejects symbolic links.'); if (entry.name === 'lib') continue; const p = `${dir}/${entry.name}`; if (entry.isDirectory()) walk(p); else paths.push(p); } }
for (const dir of ['conversation-control', ...packages]) { walk(`${dir}/src`); paths.push(`${dir}/package.json`, `${dir}/README.md`); }
walk('conversation-config'); paths.push('cortico-world-conversation-control/console.js');
paths.push('tsconfig.conversation.json', 'scripts/build-conversation-control.mjs', 'scripts/audit-conversation-control.mjs', 'scripts/verify-conversation-packages.mjs', 'CONVERSATION-CONTROL-HANDOFF.md');
for (const name of readdirSync(join(root, 'tests'))) if (/^conversation-.*\.test\.ts$/.test(name)) paths.push(`tests/${name}`);
const hash = p => createHash('sha256').update(readFileSync(join(root, p))).digest('hex');
const manifestFile = join(root, 'reports', 'conversation-control-build-manifest.json');
if (process.argv.includes('--verify')) {
  const manifest = JSON.parse(readFileSync(manifestFile, 'utf8'));
  const actual = [...paths, ...packages.flatMap(p => [`${p}/lib/index.js`, `${p}/lib/index.js.map`]), 'cortico-world-conversation-control/lib/ENV_PROMPT.md'].sort();
  const saved = new Map(manifest.files.map(file => [file.path, file.sha256]));
  const changed = actual.filter(p => !existsSync(join(root, p)) || hash(p) !== saved.get(p));
  const missing = [...saved.keys()].filter(p => !actual.includes(p));
  console.log(JSON.stringify({ verified: !changed.length && !missing.length, files: actual.length, changed, missing }, null, 2)); process.exitCode = changed.length || missing.length ? 1 : 0;
} else {
  if (process.argv.length !== 2) throw new Error('Usage: node scripts/build-conversation-control.mjs [--verify]');
  for (const p of packages) {
    mkdirSync(join(root, p, 'lib'), { recursive: true });
    // Keep each published package's module-comment paths reproducible.
    await build({ absWorkingDir: p === 'cortico-world-conversation-control' ? root : join(root, 'conversation-control'), entryPoints: [join(root, p, 'src', 'index.ts')], outfile: join(root, p, 'lib', 'index.js'), bundle: true, platform: 'node', format: 'esm', target: 'node24', packages: 'external', sourcemap: true, logLevel: 'warning' });
    paths.push(`${p}/lib/index.js`, `${p}/lib/index.js.map`);
  }
  copyFileSync(join(root, 'cortico-world-conversation-control/src/ENV_PROMPT.md'), join(root, 'cortico-world-conversation-control/lib/ENV_PROMPT.md')); paths.push('cortico-world-conversation-control/lib/ENV_PROMPT.md');
  mkdirSync(dirname(manifestFile), { recursive: true });
  const versions = Object.fromEntries(packages.map(p => [p, JSON.parse(readFileSync(join(root, p, 'package.json'), 'utf8')).version]));
  writeFileSync(manifestFile, JSON.stringify({ manifestVersion: 1, createdAt: new Date().toISOString(), node: process.version, scope: 'conversation-control source and candidate bytes; excludes existing bridge packages', versions, files: paths.sort().map(path => ({ path, sha256: hash(path) })) }, null, 2) + '\n');
  console.log(JSON.stringify({ built: packages, manifest: manifestFile, files: paths.length }));
}
